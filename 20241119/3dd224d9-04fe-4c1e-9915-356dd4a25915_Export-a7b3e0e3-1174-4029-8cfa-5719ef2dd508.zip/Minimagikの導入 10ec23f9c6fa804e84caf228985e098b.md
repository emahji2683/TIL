# Minimagikの導入

- 以下の処理をすることで、minimagikを導入した。
- gem "image_processing", ">= 1.2"をgemに導入。
- 以下をconfig/application.rbに追記

```racket
config.active_storage.variant_processor = :mini_magick
```

一方で、libvipsについては、環境構築(Dockerfile)段階から入らなくては使えなそう。

https://qiita.com/nagumo01/items/76b97a98e83604150496

https://qiita.com/P-man_Brown/items/99afba04ab5af3058e72