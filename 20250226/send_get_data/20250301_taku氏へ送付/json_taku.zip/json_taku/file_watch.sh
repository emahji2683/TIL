#!/bin/bash

# 作成したいファイル一覧（フルパスで指定）
files_to_check=(
  "edited_form_putting_chatgpt_00museum_each_page_北海道.json"
  "edited_form_putting_chatgpt_01museum_each_page_新潟.json"
  "edited_form_putting_chatgpt_02museum_each_page_長野.json"
  "edited_form_putting_chatgpt_03museum_each_page_山梨.json"
  "edited_form_putting_chatgpt_04museum_each_page_青森.json"
  "edited_form_putting_chatgpt_05museum_each_page_岩手.json"
  "edited_form_putting_chatgpt_06museum_each_page_秋田.json"
  "edited_form_putting_chatgpt_07museum_each_page_宮城.json"
  "edited_form_putting_chatgpt_08museum_each_page_山形.json"
  "edited_form_putting_chatgpt_09museum_each_page_福島.json"
  "edited_form_putting_chatgpt_10museum_each_page_富山.json"
  "edited_form_putting_chatgpt_11museum_each_page_石川.json"
  "edited_form_putting_chatgpt_12museum_each_page_福井.json"
  "edited_form_putting_chatgpt_13museum_each_page_東京.json"
  "edited_form_putting_chatgpt_14museum_each_page_神奈川.json"
  "edited_form_putting_chatgpt_15museum_each_page_埼玉.json"
  "edited_form_putting_chatgpt_16museum_each_page_千葉.json"
  "edited_form_putting_chatgpt_17museum_each_page_茨城.json"
  "edited_form_putting_chatgpt_18museum_each_page_栃木.json"
  "edited_form_putting_chatgpt_19museum_each_page_群馬.json"
  "edited_form_putting_chatgpt_20museum_each_page_愛知.json"
  "edited_form_putting_chatgpt_21museum_each_page_岐阜.json"
  "edited_form_putting_chatgpt_22museum_each_page_三重.json"
  "edited_form_putting_chatgpt_23museum_each_page_静岡.json"
  "edited_form_putting_chatgpt_24museum_each_page_大阪.json"
  "edited_form_putting_chatgpt_25museum_each_page_兵庫.json"
  "edited_form_putting_chatgpt_26museum_each_page_京都.json"
  "edited_form_putting_chatgpt_27museum_each_page_滋賀.json"
  "edited_form_putting_chatgpt_28museum_each_page_奈良.json"
  "edited_form_putting_chatgpt_29museum_each_page_和歌山.json"
  "edited_form_putting_chatgpt_30museum_each_page_香川.json"
  "edited_form_putting_chatgpt_31museum_each_page_愛媛.json"
  "edited_form_putting_chatgpt_32museum_each_page_徳島.json"
  "edited_form_putting_chatgpt_33museum_each_page_高知.json"
  "edited_form_putting_chatgpt_34museum_each_page_広島.json"
  "edited_form_putting_chatgpt_35museum_each_page_岡山.json"
  "edited_form_putting_chatgpt_36museum_each_page_鳥取.json"
  "edited_form_putting_chatgpt_37museum_each_page_島根.json"
  "edited_form_putting_chatgpt_38museum_each_page_山口.json"
  "edited_form_putting_chatgpt_39museum_each_page_福岡.json"
  "edited_form_putting_chatgpt_40museum_each_page_佐賀.json"
  "edited_form_putting_chatgpt_41museum_each_page_長崎.json"
  "edited_form_putting_chatgpt_42museum_each_page_熊本.json"
  "edited_form_putting_chatgpt_43museum_each_page_大分.json"
  "edited_form_putting_chatgpt_44museum_each_page_宮崎.json"
  "edited_form_putting_chatgpt_45museum_each_page_鹿児島.json"
  "edited_form_putting_chatgpt_46museum_each_page_沖縄.json"
)

# ヘッダーを表示
echo -e "Filename\t\tStatus"

# ファイル作成状況をチェック
for file in "${files_to_check[@]}"; do
  if [ -e "$file" ]; then
    echo -e "$(basename "$file")\t\tCreated"
  else
    echo -e "$(basename "$file")\t\tNot Created"
  fi
done
